package com.sofka.canterauy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CanterauyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CanterauyApplication.class, args);
	}

}
